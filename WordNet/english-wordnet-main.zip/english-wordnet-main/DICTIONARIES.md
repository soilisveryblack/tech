# Reference Dictionaries

This is a list of reference dictionaries that should be used when considering 
changes to Open English WordNet

* [American Heritage Dictionary](https://www.ahdictionary.com/)
* [Cambridge Dictionary](https://dictionary.cambridge.org/)
* [Collins Dictionary](https://www.collinsdictionary.com/dictionary/english)
* [Dictionary.com](https://www.dictionary.com/)
* [Oxford](https://www.oed.com/)
* [Macmillan](https://www.macmillandictionary.com/)
* [Merriam-Webster](https://www.merriam-webster.com/)
* [Wiktionary](https://en.wiktionary.org/wiki/Wiktionary:Main_Page)
