---
name: Change example
about: Add, remove or alter a synset's examples
title: ''
labels: example
assignees: ''

---

**Synset**
Please give the code of the synset of the form ewn-00000000-x and the lemma

**Example**
Please state the example you are changing and whether this is an addition, removal or change of an existing example.

**Motivation**
Please explain why you are proposing the change
