---
name: Other change to WordNet
about: Some other change to the content of the resource
title: ''
labels: ''
assignees: ''

---

**Affected synsets**
Give information about the synsets that would be affected. If referring to individual synsets please give the synset identifier of the form ewn-00000000-x

**Proposed changes**
Please explain what you expect to change

**Motivation**
Please explain why you think this change should be made
