---
name: Change relation
about: Change the source, target or type of an existing relation
title: ''
labels: change relation
assignees: ''

---

**Existing relation**
Please give the existing source, target and relation type. You should give the code for the synset of the form ewn-00000000-x and the lemma and the relation by keyword as in https://globalwordnet.github.io/gwadoc/

**Proposed change**
Please indicate if you wish to change the source, target or relation type

**Motivation**
Please explain the reason for the change
