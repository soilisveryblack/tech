---
name: Add a relation
about: Add a link between two synsets that does not already exist
title: ''
labels: add relation
assignees: ''

---

**The source synset**
Please give the code of the form ewn-00000000-x and the lemma

**The target synset**
Please give the code of the form ewn-00000000-x and the lemma

** The relation**
The relation as listed on https://globalwordnet.github.io/gwadoc/

**Motivation**
Please explain why this relation should be added
