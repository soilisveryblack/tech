---
name: Merge synsets
about: Two synsets describe the same concept and should be merged
title: ''
labels: synset duplicate
assignees: ''

---

**Synsets**
Please list the synsets that you think are duplicates. For each synset please give the code of the form ewn-0000000-x, the lemma and the definitions

**Motivation**
Explain why you think that these are duplicates
