---
name: Change definition
about: Change the definition of the synset
title: ''
labels: definition
assignees: ''

---

**Synset**
Please give the code of the synset of the form ewn-00000000-x and the lemma

**New definition**
Please state the new definition you are proposing

**Motivation**
Please explain why you are proposing the change
